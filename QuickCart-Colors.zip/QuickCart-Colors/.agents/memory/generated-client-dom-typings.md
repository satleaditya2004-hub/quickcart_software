---
name: Generated client DOM typings
description: Shared TypeScript compiler settings needed by the generated Orval fetch client.
---

The generated API client uses iterable DOM APIs such as `Headers.entries()`, so the API client library must include both `dom` and `dom.iterable` in its TypeScript `lib` settings.

**Why:** The codegen step can succeed while the workspace library typecheck fails if iterable DOM declarations are absent.

**How to apply:** When generated client code reports missing iterable DOM members, fix the library compiler target rather than editing generated files.