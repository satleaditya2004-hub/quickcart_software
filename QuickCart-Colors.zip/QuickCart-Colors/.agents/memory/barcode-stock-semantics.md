---
name: Barcode stock semantics
description: QuickCart's inventory meaning for repeated product barcodes and per-unit scan records.
---

A barcode identifies a product type, not necessarily one physical unit. Repeated stock-in scans with the same barcode are valid and each creates one scan record while increasing product stock by one. Checkout selects one unsold matching record and decreases stock only after marking that record sold.

**Why:** Retail product barcodes are commonly identical across all units on the shelf, so enforcing barcode uniqueness prevents quantity from increasing during normal stock intake.

**How to apply:** Preserve duplicate-barcode support in the scan-record schema and stock-in route. Checkout must filter for unsold matches and handle the case where every matching unit has already been sold.