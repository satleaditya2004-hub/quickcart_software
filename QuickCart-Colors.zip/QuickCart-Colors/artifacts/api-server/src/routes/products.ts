import { Router, type IRouter } from "express";
import { asc, eq } from "drizzle-orm";
import {
  CreateProductBody,
  CreateProductResponse,
  DeleteProductParams,
  ListProductsQueryParams,
  ListProductsResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
} from "@workspace/api-zod";
import { db, productsTable } from "@workspace/db";
import { dateToSql } from "../lib/quickcart";

const router: IRouter = Router();

router.get("/products", async (req, res): Promise<void> => {
  const parsed = ListProductsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const products = await db
    .select()
    .from(productsTable)
    .orderBy(asc(productsTable.name));
  const search = parsed.data.search?.trim().toLowerCase();
  const filtered = search
    ? products.filter((product) => product.name.toLowerCase().includes(search))
    : products;

  res.json(ListProductsResponse.parse(filtered));
});

router.post("/products", async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db
    .insert(productsTable)
    .values({
      name: parsed.data.name.trim(),
      weight: parsed.data.weight.trim(),
      mrp: parsed.data.mrp,
      sellingPrice: parsed.data.sellingPrice,
      manufactureDate: dateToSql(parsed.data.manufactureDate),
      expiryDate: dateToSql(parsed.data.expiryDate),
    })
    .returning();

  res.status(201).json(CreateProductResponse.parse(product));
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db
    .update(productsTable)
    .set({
      name: parsed.data.name.trim(),
      weight: parsed.data.weight.trim(),
      mrp: parsed.data.mrp,
      sellingPrice: parsed.data.sellingPrice,
      manufactureDate: dateToSql(parsed.data.manufactureDate),
      expiryDate: dateToSql(parsed.data.expiryDate),
      updatedAt: new Date(),
    })
    .where(eq(productsTable.id, params.data.id))
    .returning();

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(UpdateProductResponse.parse(product));
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [product] = await db
    .delete(productsTable)
    .where(eq(productsTable.id, params.data.id))
    .returning();

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;