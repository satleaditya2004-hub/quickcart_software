import { Router, type IRouter } from "express";
import analysisRouter from "./analysis";
import healthRouter from "./health";
import productsRouter from "./products";
import scansRouter from "./scans";

const router: IRouter = Router();

router.use(healthRouter);
router.use(productsRouter);
router.use(scansRouter);
router.use(analysisRouter);

export default router;
