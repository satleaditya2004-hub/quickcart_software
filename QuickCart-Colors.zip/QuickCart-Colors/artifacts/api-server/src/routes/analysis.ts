import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import {
  GetAnalysisQueryParams,
  GetAnalysisResponse,
} from "@workspace/api-zod";
import { db, productsTable, scanRecordsTable } from "@workspace/db";
import { addDays, daysBetween, todaySql } from "../lib/quickcart";

const router: IRouter = Router();

router.get("/analysis", async (req, res): Promise<void> => {
  const parsed = GetAnalysisQueryParams.safeParse({
    ...req.query,
    period:
      req.query.period === undefined
        ? 30
        : Number(Array.isArray(req.query.period) ? req.query.period[0] : req.query.period),
  });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const products = await db.select().from(productsTable).orderBy(desc(productsTable.stockCount));
  const records = await db
    .select({
      record: scanRecordsTable,
      productName: productsTable.name,
    })
    .from(scanRecordsTable)
    .innerJoin(productsTable, eq(scanRecordsTable.productId, productsTable.id));
  const today = todaySql();
  const period = parsed.data.period;
  const soldRecords = records.filter((row) => row.record.sellingDate !== null);
  const periodSoldRecords = soldRecords.filter(
    (row) => daysBetween(row.record.sellingDate!, today) >= 0 && daysBetween(row.record.sellingDate!, today) < period,
  );

  const alerts: Array<{
    type: "low-stock" | "expiring" | "expired" | "reorder";
    title: string;
    detail: string;
    severity: "high" | "medium" | "low";
  }> = [];
  const rankings = products.map((product) => {
    const productRecords = records.filter((row) => row.record.productId === product.id);
    const productSold = productRecords.filter((row) => row.record.sellingDate !== null);
    const productPeriodSold = periodSoldRecords.filter((row) => row.record.productId === product.id);
    const avgDaysToSell = productSold.length
      ? productSold.reduce(
          (sum, row) => sum + daysBetween(row.record.scanDate, row.record.sellingDate!),
          0,
        ) / productSold.length
      : 0;
    const revenue = productSold.reduce((sum, row) => sum + row.record.sellingPriceSnapshot, 0);
    const discountGiven = productSold.reduce(
      (sum, row) => sum + Math.max(row.record.mrpSnapshot - row.record.sellingPriceSnapshot, 0),
      0,
    );
    const unsold = productRecords.filter((row) => row.record.sellingDate === null);
    const expiring = unsold.filter((row) => {
      const days = daysBetween(today, row.record.expiryDateSnapshot);
      return days >= 0 && days <= 7;
    });
    const expired = unsold.filter((row) => daysBetween(today, row.record.expiryDateSnapshot) < 0);
    const recentSales = productSold.filter(
      (row) => daysBetween(row.record.sellingDate!, today) >= 0 && daysBetween(row.record.sellingDate!, today) < 14,
    ).length;
    const dailyVelocity = recentSales / 14;
    const estimatedDaysLeft = dailyVelocity > 0 ? product.stockCount / dailyVelocity : Infinity;

    if (product.stockCount < 5) {
      alerts.push({
        type: "low-stock",
        title: `${product.name} is running low`,
        detail: `${product.stockCount} unit${product.stockCount === 1 ? "" : "s"} left in stock`,
        severity: product.stockCount === 0 ? "high" : "medium",
      });
    }
    if (expiring.length) {
      alerts.push({
        type: "expiring",
        title: `${product.name} has expiry risk`,
        detail: `${expiring.length} unsold unit${expiring.length === 1 ? "" : "s"} expire within 7 days`,
        severity: "medium",
      });
    }
    if (expired.length) {
      alerts.push({
        type: "expired",
        title: `${product.name} has expired units`,
        detail: `${expired.length} unsold unit${expired.length === 1 ? "" : "s"} need attention`,
        severity: "high",
      });
    }
    if (estimatedDaysLeft < 3 && dailyVelocity > 0) {
      alerts.push({
        type: "reorder",
        title: `Reorder ${product.name}`,
        detail: `At the recent pace, stock may run out in ${Math.max(1, Math.round(estimatedDaysLeft))} day${Math.round(estimatedDaysLeft) === 1 ? "" : "s"}`,
        severity: "high",
      });
    }

    let status: "healthy" | "low-stock" | "near-expiry" | "slow-moving" = "healthy";
    if (product.stockCount < 5) status = "low-stock";
    else if (expiring.length) status = "near-expiry";
    else if (productSold.length > 0 && avgDaysToSell > 14) status = "slow-moving";

    return {
      productId: product.id,
      productName: product.name,
      unitsSold: productPeriodSold.length,
      revenue,
      avgDaysToSell: Number(avgDaysToSell.toFixed(1)),
      stockLeft: product.stockCount,
      discountGiven,
      status,
    };
  });

  const trend = Array.from({ length: 7 }, (_, index) => {
    const date = addDays(today, index - 6);
    const dayRecords = soldRecords.filter((row) => row.record.sellingDate === date);
    return {
      date,
      units: dayRecords.length,
      revenue: dayRecords.reduce((sum, row) => sum + row.record.sellingPriceSnapshot, 0),
    };
  });

  const revenueShare = products
    .map((product) => ({
      productName: product.name,
      revenue: soldRecords
        .filter((row) => row.record.productId === product.id)
        .reduce((sum, row) => sum + row.record.sellingPriceSnapshot, 0),
    }))
    .filter((item) => item.revenue > 0)
    .sort((a, b) => b.revenue - a.revenue);

  res.json(
    GetAnalysisResponse.parse({
      totals: {
        products: products.length,
        unitsInStock: products.reduce((sum, product) => sum + product.stockCount, 0),
        unitsSold: soldRecords.length,
        revenue: soldRecords.reduce((sum, row) => sum + row.record.sellingPriceSnapshot, 0),
        lowStock: products.filter((product) => product.stockCount < 5).length,
        expiringSoon: records.filter(
          (row) =>
            row.record.sellingDate === null &&
            daysBetween(today, row.record.expiryDateSnapshot) >= 0 &&
            daysBetween(today, row.record.expiryDateSnapshot) <= 7,
        ).length,
        expiredUnsold: records.filter(
          (row) =>
            row.record.sellingDate === null &&
            daysBetween(today, row.record.expiryDateSnapshot) < 0,
        ).length,
      },
      alerts,
      rankings: rankings.sort((a, b) => b.unitsSold - a.unitsSold),
      salesTrend: trend,
      revenueShare,
    }),
  );
});

export default router;