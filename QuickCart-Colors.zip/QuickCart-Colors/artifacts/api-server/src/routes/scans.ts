import { Router, type IRouter } from "express";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import {
  ListScanRecordsQueryParams,
  ListScanRecordsResponse,
  SellBarcodeBody,
  SellBarcodeResponse,
  StockInBarcodeBody,
  StockInBarcodeResponse,
} from "@workspace/api-zod";
import { db, productsTable, scanRecordsTable } from "@workspace/db";
import { dateToSql, timeSql } from "../lib/quickcart";

const router: IRouter = Router();

async function getJoinedRecord(id: number) {
  const [row] = await db
    .select({
      record: scanRecordsTable,
      productName: productsTable.name,
    })
    .from(scanRecordsTable)
    .innerJoin(productsTable, eq(scanRecordsTable.productId, productsTable.id))
    .where(eq(scanRecordsTable.id, id));
  return row ? { ...row.record, productName: row.productName } : undefined;
}

router.get("/scan-records", async (req, res): Promise<void> => {
  const parsed = ListScanRecordsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const rows = await db
    .select({
      record: scanRecordsTable,
      productName: productsTable.name,
    })
    .from(scanRecordsTable)
    .innerJoin(productsTable, eq(scanRecordsTable.productId, productsTable.id))
    .orderBy(desc(scanRecordsTable.id));

  const search = parsed.data.search?.trim().toLowerCase();
  const filtered = rows
    .map((row) => ({ ...row.record, productName: row.productName }))
    .filter((row) => {
      if (parsed.data.productId !== undefined && row.productId !== parsed.data.productId) {
        return false;
      }
      if (parsed.data.unsoldOnly && row.sellingDate !== null) {
        return false;
      }
      if (
        search &&
        ![row.barcode, row.productName, row.scanDate, row.sellingDate ?? ""]
          .join(" ")
          .toLowerCase()
          .includes(search)
      ) {
        return false;
      }
      return true;
    });

  res.json(ListScanRecordsResponse.parse(filtered));
});

router.post("/scan-records/stock-in", async (req, res): Promise<void> => {
  const parsed = StockInBarcodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, parsed.data.productId));
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const scanDate = dateToSql(new Date());
  const [record] = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(scanRecordsTable)
      .values({
        productId: product.id,
        barcode: parsed.data.barcode.trim(),
        scanDate,
        scanTime: timeSql(),
        mrpSnapshot: product.mrp,
        expiryDateSnapshot: product.expiryDate,
        sellingPriceSnapshot: product.sellingPrice,
      })
      .returning();

    await tx
      .update(productsTable)
      .set({ stockCount: sql`${productsTable.stockCount} + 1` })
      .where(eq(productsTable.id, product.id));
    return [created];
  });

  const response = await getJoinedRecord(record.id);
  res.status(201).json(StockInBarcodeResponse.parse(response));
});

router.post("/scan-records/sell", async (req, res): Promise<void> => {
  const parsed = SellBarcodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const barcode = parsed.data.barcode.trim();
  const [record] = await db
    .select()
    .from(scanRecordsTable)
    .where(and(eq(scanRecordsTable.barcode, barcode), isNull(scanRecordsTable.sellingDate)))
    .orderBy(scanRecordsTable.id);
  if (!record) {
    const [knownBarcode] = await db
      .select({ id: scanRecordsTable.id })
      .from(scanRecordsTable)
      .where(eq(scanRecordsTable.barcode, barcode));
    res.status(knownBarcode ? 409 : 404).json({
      error: knownBarcode ? "All units with this barcode have already been sold" : "Barcode not found in stock",
    });
    return;
  }

  const sellingDate = dateToSql(new Date());
  const sold = await db.transaction(async (tx) => {
    const [updated] = await tx
      .update(scanRecordsTable)
      .set({ sellingDate, sellingTime: timeSql() })
      .where(and(eq(scanRecordsTable.id, record.id), isNull(scanRecordsTable.sellingDate)))
      .returning({ id: scanRecordsTable.id });
    if (!updated) return false;
    await tx
      .update(productsTable)
      .set({
        stockCount: sql`GREATEST(${productsTable.stockCount} - 1, 0)`,
      })
      .where(eq(productsTable.id, record.productId));
    return true;
  });
  if (!sold) {
    res.status(409).json({ error: "This unit has already been sold" });
    return;
  }

  const response = await getJoinedRecord(record.id);
  res.json(SellBarcodeResponse.parse(response));
});

export default router;