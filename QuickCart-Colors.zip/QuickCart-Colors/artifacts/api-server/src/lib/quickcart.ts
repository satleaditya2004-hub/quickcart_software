export function dateToSql(value: Date): string {
  return value.toISOString().slice(0, 10);
}

export function todaySql(): string {
  return dateToSql(new Date());
}

export function timeSql(): string {
  return new Date().toISOString().slice(11, 19);
}

export function daysBetween(start: string, end: string): number {
  const startMs = Date.parse(`${start}T00:00:00Z`);
  const endMs = Date.parse(`${end}T00:00:00Z`);
  return Math.round((endMs - startMs) / 86_400_000);
}

export function addDays(date: string, amount: number): string {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + amount);
  return value.toISOString().slice(0, 10);
}