import { useEffect, useMemo, useRef, useState, createContext, useContext, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import {
  AlertTriangle, ArrowUpRight, BarChart3, Barcode, Box, CalendarDays, Camera,
  Check, CircleAlert, Clock3, Database, Info, LayoutDashboard, MoreHorizontal,
  Package, Pencil, Play, Plus, RefreshCw, Search, ScanLine, ShoppingCart,
  Square, Tag, Trash2, TrendingUp, Wifi, X,
} from 'lucide-react';
import {
  getGetAnalysisQueryKey, getListProductsQueryKey, getListScanRecordsQueryKey,
  useCreateProduct, useDeleteProduct, useGetAnalysis, useListProducts,
  useListScanRecords, useSellBarcode, useStockInBarcode, useUpdateProduct,
} from '@workspace/api-client-react';
import type { Analysis, Product, ScanRecord } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type Session = { productId?: number; productName?: string; isScanning: boolean };
const SessionContext = createContext<{ session: Session; setSession: (session: Session) => void } | null>(null);
const useSession = () => useContext(SessionContext)!;

const money = (value: number) => `₹${Number(value || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const date = (value?: string | null) => value ? new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const shortDate = (value?: string | null) => value ? new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : '—';
const errorText = (error: unknown) => (error && typeof error === 'object' && 'error' in error ? String((error as { error: unknown }).error) : 'Something went wrong. Try again.');
const initials = (name: string) => name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase();

function NavIcon({ name }: { name: string }) {
  const props = { size: 17, strokeWidth: 1.8 };
  if (name === 'list') return <LayoutDashboard {...props} />;
  if (name === 'scan') return <ScanLine {...props} />;
  if (name === 'data') return <Database {...props} />;
  if (name === 'sell') return <ShoppingCart {...props} />;
  return <BarChart3 {...props} />;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const title = location === '/list' ? 'Product register' : location === '/scan' ? 'Stock intake' : location === '/data' ? 'Scan intelligence' : location === '/sell' ? 'Checkout' : 'Business pulse';
  const nav = [
    { href: '/list', label: 'List', note: 'Catalog' },
    { href: '/scan', label: 'Scan', note: 'Stock in' },
    { href: '/data', label: 'Data', note: 'Per-unit' },
    { href: '/sell', label: 'Sell', note: 'Checkout' },
    { href: '/analysis', label: 'Analysis', note: 'Signals' },
  ];
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Link href="/list" className="brand" data-testid="link-brand">
          <span className="brand-mark">Q</span><span className="brand-name">quick<em>cart</em></span>
        </Link>
        <div className="nav-label">Operations</div>
        <nav className="nav-list" aria-label="Primary navigation">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className={`nav-item ${location === item.href ? 'active' : ''}`} data-testid={`link-nav-${item.label.toLowerCase()}`}>
              <NavIcon name={item.href.slice(1)} /><span>{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="sidebar-foot"><span className="status-dot" />System synced<br /><span style={{ opacity: .7 }}>Local shop floor · live</span></div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div><div className="topbar-kicker">QuickCart / {location.slice(1) || 'home'}</div><div className="topbar-title">{title}</div></div>
          <div className="clock"><Clock3 size={13} style={{ verticalAlign: 'middle', marginRight: 5 }} />{new Date().toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short' })}</div>
        </header>
        {children}
      </main>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {nav.map((item) => <Link key={item.href} href={item.href} className={location === item.href ? 'active' : ''} data-testid={`mobile-link-${item.label.toLowerCase()}`}><NavIcon name={item.href.slice(1)} /><span>{item.label}</span></Link>)}
      </nav>
    </div>
  );
}

function Home() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    const timer = window.setTimeout(() => setLocation('/list'), 950);
    return () => window.clearTimeout(timer);
  }, [setLocation]);
  return <div className="splash"><div className="splash-mark">Q</div><h1>quick<span>cart</span></h1><p>Inventory you can trust.</p></div>;
}

type ProductForm = { name: string; weight: string; mrp: string; sellingPrice: string; manufactureDate: string; expiryDate: string };
const blankForm: ProductForm = { name: '', weight: '', mrp: '', sellingPrice: '', manufactureDate: '', expiryDate: '' };
function ProductModal({ product, onClose, onSaved }: { product?: Product; onClose: () => void; onSaved: (message: string) => void }) {
  const [form, setForm] = useState<ProductForm>(product ? {
    name: product.name, weight: product.weight, mrp: String(product.mrp), sellingPrice: String(product.sellingPrice),
    manufactureDate: product.manufactureDate.slice(0, 10), expiryDate: product.expiryDate.slice(0, 10),
  } : blankForm);
  const [formError, setFormError] = useState('');
  const create = useCreateProduct();
  const update = useUpdateProduct();
  const pending = create.isPending || update.isPending;
  const set = (key: keyof ProductForm, value: string) => setForm((old) => ({ ...old, [key]: value }));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.name.trim() || !form.weight.trim() || !form.manufactureDate || !form.expiryDate || Number.isNaN(Number(form.mrp)) || Number.isNaN(Number(form.sellingPrice))) {
      setFormError('Complete each field with a valid value before saving.');
      return;
    }
    const data = { name: form.name.trim(), weight: form.weight.trim(), mrp: Number(form.mrp), sellingPrice: Number(form.sellingPrice), manufactureDate: form.manufactureDate, expiryDate: form.expiryDate };
    const onSuccess = () => { queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); onSaved(product ? 'Product details updated.' : 'Product registered.'); onClose(); };
    if (product) update.mutate({ id: product.id, data }, { onSuccess });
    else create.mutate({ data }, { onSuccess });
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}>
    <form className="modal" onSubmit={submit}>
      <div className="modal-head"><div><h2>{product ? 'Edit product' : 'Register product'}</h2><p className="modal-subtitle">{product ? 'Keep this product’s shelf truth current.' : 'Give the shelf a reliable identity.'}</p></div><button type="button" className="icon-button" onClick={onClose} aria-label="Close" data-testid="button-close-product-modal"><X /></button></div>
      <div className="form-grid">
        <div className="field full"><label htmlFor="product-name">Product name</label><input id="product-name" value={form.name} onChange={(e) => set('name', e.target.value)} autoFocus data-testid="input-product-name" placeholder="e.g. Rosehip face wash" /></div>
        <div className="field"><label htmlFor="product-weight">Weight / size</label><input id="product-weight" value={form.weight} onChange={(e) => set('weight', e.target.value)} data-testid="input-product-weight" placeholder="e.g. 120 g" /></div>
        <div className="field"><label htmlFor="product-mrp">MRP</label><input id="product-mrp" type="number" min="0" step="0.01" value={form.mrp} onChange={(e) => set('mrp', e.target.value)} data-testid="input-product-mrp" placeholder="0.00" /></div>
        <div className="field"><label htmlFor="product-price">Selling price</label><input id="product-price" type="number" min="0" step="0.01" value={form.sellingPrice} onChange={(e) => set('sellingPrice', e.target.value)} data-testid="input-product-price" placeholder="0.00" /></div>
        <div className="field"><label htmlFor="product-made">Manufactured</label><input id="product-made" type="date" value={form.manufactureDate} onChange={(e) => set('manufactureDate', e.target.value)} data-testid="input-product-manufacture" /></div>
        <div className="field"><label htmlFor="product-expiry">Expiry date</label><input id="product-expiry" type="date" value={form.expiryDate} onChange={(e) => set('expiryDate', e.target.value)} data-testid="input-product-expiry" /></div>
      </div>
      {formError && <p style={{ color: '#a33e47', fontSize: 12, margin: '14px 0 0' }} data-testid="status-form-error">{formError}</p>}
      {(create.isError || update.isError) && <p style={{ color: '#a33e47', fontSize: 12, margin: '14px 0 0' }}>{errorText(create.error || update.error)}</p>}
      <div className="form-actions"><button type="button" className="button button-ghost" onClick={onClose} data-testid="button-cancel-product">Cancel</button><button className="button button-primary" disabled={pending} data-testid="button-save-product">{pending ? 'Saving…' : product ? 'Save changes' : 'Register product'}</button></div>
    </form>
  </div>;
}

function InfoModal({ product, onClose }: { product: Product; onClose: () => void }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}>
    <div className="modal"><div className="modal-head"><div><h2>{product.name}</h2><p className="modal-subtitle">Product record · updated {date(product.updatedAt)}</p></div><button className="icon-button" onClick={onClose} aria-label="Close" data-testid="button-close-info-modal"><X /></button></div>
      <div className="detail-list">
        <div className="detail-item"><span>Weight / size</span><strong>{product.weight}</strong></div><div className="detail-item"><span>On hand</span><strong>{product.stockCount} units</strong></div>
        <div className="detail-item"><span>MRP</span><strong>{money(product.mrp)}</strong></div><div className="detail-item"><span>Selling price</span><strong>{money(product.sellingPrice)}</strong></div>
        <div className="detail-item"><span>Manufactured</span><strong>{date(product.manufactureDate)}</strong></div><div className="detail-item"><span>Expires</span><strong>{date(product.expiryDate)}</strong></div>
      </div>
      <div className="form-actions"><button className="button button-primary" onClick={onClose} data-testid="button-done-info">Done</button></div>
    </div>
  </div>;
}

function ConfirmDelete({ product, onClose, onDeleted }: { product: Product; onClose: () => void; onDeleted: () => void }) {
  const del = useDeleteProduct();
  const confirm = () => del.mutate({ id: product.id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); onDeleted(); onClose(); } });
  return <div className="modal-backdrop" role="presentation"><div className="modal" style={{ maxWidth: 420 }}><div className="modal-head"><div><h2>Remove product?</h2><p className="modal-subtitle">This removes <strong>{product.name}</strong> from your register. Scan history stays intact.</p></div><button className="icon-button" onClick={onClose} aria-label="Close" data-testid="button-close-delete"><X /></button></div><div className="form-actions" style={{ borderTop: 0, marginTop: 8 }}><button className="button button-ghost" onClick={onClose} data-testid="button-cancel-delete">Keep it</button><button className="button button-danger" onClick={confirm} disabled={del.isPending} data-testid="button-confirm-delete"><Trash2 size={15} />{del.isPending ? 'Removing…' : 'Remove product'}</button></div>{del.isError && <p style={{ color: '#a33e47', fontSize: 12 }}>{errorText(del.error)}</p>}</div></div>;
}

function ListPage() {
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<'create' | 'edit' | 'info' | 'delete' | null>(null);
  const [active, setActive] = useState<Product | undefined>();
  const [notice, setNotice] = useState('');
  const productsQuery = useListProducts(search ? { search } : undefined);
  const products = productsQuery.data ?? [];
  useEffect(() => { if (!notice) return undefined; const timer = window.setTimeout(() => setNotice(''), 2800); return () => window.clearTimeout(timer); }, [notice]);
  const open = (kind: typeof modal, product?: Product) => { setActive(product); setModal(kind); };
  return <><div className="page">
    <div className="page-heading"><div><div className="eyebrow">The register</div><h1>Your shelf, accounted for.</h1><p className="page-subtitle">Every product has a place. Every unit has a story.</p></div><button className="button button-primary" onClick={() => open('create')} data-testid="button-register-product"><Plus size={16} />Register product</button></div>
    <div className="catalog-toolbar"><div className="search-bar"><Search size={17} /><input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search the product register…" aria-label="Search products" data-testid="input-search-products" />{search && <button className="icon-button" onClick={() => setSearch('')} aria-label="Clear search" data-testid="button-clear-search"><X size={15} /></button>}</div><span className="result-count" data-testid="text-product-count">{products.length} {products.length === 1 ? 'product' : 'products'} visible</span></div>
    {productsQuery.isLoading ? <div className="skeleton-grid">{[1, 2, 3, 4, 5, 6].map((i) => <div className="skeleton" key={i} />)}</div> : productsQuery.isError ? <div className="error-state"><CircleAlert className="empty-icon" /><strong>Couldn’t load the register</strong><span>{errorText(productsQuery.error)}</span><br /><button className="button button-ghost" style={{ marginTop: 15 }} onClick={() => productsQuery.refetch()} data-testid="button-retry-products"><RefreshCw size={14} />Try again</button></div> : products.length === 0 ? <div className="empty-state"><Package className="empty-icon" /><strong>{search ? 'No matching products' : 'Your register is ready for its first product'}</strong><span>{search ? 'Try another name or clear the search.' : 'Register a product, then scan its first unit into stock.'}</span>{!search && <><br /><button className="button button-primary" style={{ marginTop: 17 }} onClick={() => open('create')} data-testid="button-empty-register"><Plus size={14} />Register first product</button></>}</div> : <div className="product-grid">
      {products.map((product) => <article className="product-card" key={product.id} data-testid={`card-product-${product.id}`}><div className="product-head"><div><h2 className="product-name">{product.name}</h2><div className="product-weight">{product.weight}</div></div><span className={`stock-pill ${product.stockCount < 5 ? 'low' : ''}`}>{product.stockCount} in stock</span></div><div className="price-row"><span className="price">{money(product.sellingPrice)}</span><span className="mrp">{money(product.mrp)}</span></div><div className="card-meta"><span><CalendarDays size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} />Exp {shortDate(product.expiryDate)}</span><span>Updated {shortDate(product.updatedAt)}</span></div><div className="card-actions"><button className="button button-soft" style={{ flex: 1 }} onClick={() => open('info', product)} data-testid={`button-info-product-${product.id}`}><Info size={14} />Details</button><button className="icon-button" onClick={() => open('edit', product)} aria-label={`Edit ${product.name}`} data-testid={`button-edit-product-${product.id}`}><Pencil size={15} /></button><button className="icon-button" onClick={() => open('delete', product)} aria-label={`Delete ${product.name}`} data-testid={`button-delete-product-${product.id}`}><Trash2 size={15} /></button></div></article>)}
    </div>}
  </div>{modal === 'create' && <ProductModal onClose={() => setModal(null)} onSaved={setNotice} />}{modal === 'edit' && active && <ProductModal product={active} onClose={() => setModal(null)} onSaved={setNotice} />}{modal === 'info' && active && <InfoModal product={active} onClose={() => setModal(null)} />}{modal === 'delete' && active && <ConfirmDelete product={active} onClose={() => setModal(null)} onDeleted={() => setNotice('Product removed from the register.')} />}{notice && <div className="toast-note" data-testid="status-list-notice"><Check size={15} style={{ verticalAlign: 'middle', marginRight: 7 }} />{notice}</div>}</>;
}

function ProductSelect({ products, value, onChange, label = 'Product' }: { products: Product[]; value?: number; onChange: (value?: number) => void; label?: string }) {
  return <div><label className="select-label" htmlFor="product-selector">{label}</label><select id="product-selector" className="select-field" value={value ?? ''} onChange={(event) => onChange(event.target.value ? Number(event.target.value) : undefined)} data-testid="select-product"><option value="">Choose a product…</option>{products.map((product) => <option key={product.id} value={product.id}>{product.name} · {product.stockCount} in stock</option>)}</select></div>;
}

function ScanPage() {
  const { session, setSession } = useSession();
  const productsQuery = useListProducts();
  const products = productsQuery.data ?? [];
  const [selectedId, setSelectedId] = useState<number | undefined>(session.productId);
  const selected = products.find((item) => item.id === selectedId);
  const [barcode, setBarcode] = useState('');
  const [scanLog, setScanLog] = useState<ScanRecord[]>([]);
  const [cameraNote, setCameraNote] = useState('');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const stockIn = useStockInBarcode();
  const active = session.isScanning;
  useEffect(() => { if (selected && selected.id !== session.productId) setSession({ ...session, productId: selected.id, productName: selected.name }); }, [selected, session, setSession]);
  const choose = (id?: number) => { setSelectedId(id); const product = products.find((item) => item.id === id); setSession({ productId: id, productName: product?.name, isScanning: false }); setScanLog([]); };
  const start = () => { if (!selectedId) return; setSession({ productId: selectedId, productName: selected?.name, isScanning: true }); setTimeout(() => inputRef.current?.focus(), 50); };
  const end = () => setSession({ ...session, isScanning: false });
  const completeStockIn = (record: ScanRecord) => {
    setScanLog((old) => [record, ...old]);
    queryClient.setQueryData<Product[]>(getListProductsQueryKey(), (current) =>
      current?.map((product) => product.id === record.productId ? { ...product, stockCount: product.stockCount + 1 } : product),
    );
    queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListScanRecordsQueryKey() });
  };
  const submitBarcode = (event?: FormEvent) => {
    event?.preventDefault();
    const clean = barcode.trim();
    if (!clean || !selectedId || !active || stockIn.isPending) return;
    stockIn.mutate({ data: { productId: selectedId, barcode: clean } }, {
      onSuccess: (record) => { completeStockIn(record); setBarcode(''); setTimeout(() => inputRef.current?.focus(), 20); },
    });
  };
  useEffect(() => {
    if (!cameraOpen) return undefined;
    let stopped = false;
    let timer: number | undefined;
    const detectorConstructor = (window as unknown as {
      BarcodeDetector?: new (options?: { formats?: string[] }) => {
        detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>>;
      };
    }).BarcodeDetector;

    const stopCamera = () => {
      stopped = true;
      if (timer) window.clearTimeout(timer);
      cameraStreamRef.current?.getTracks().forEach((track) => track.stop());
      cameraStreamRef.current = null;
    };

    const startCamera = async () => {
      if (!active || !selectedId) {
        setCameraError('Start a stock-in session and choose a product first.');
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraError('Camera access is not supported here. Use a paired scanner or enter the barcode manually.');
        return;
      }
      if (!detectorConstructor) {
        setCameraError('This browser cannot decode barcodes from camera video yet. Use a paired scanner or enter the barcode manually.');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } } });
        cameraStreamRef.current = stream;
        if (!videoRef.current) return;
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        const detector = new detectorConstructor({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39'] });
        const detect = async () => {
          if (stopped || !videoRef.current) return;
          try {
            const matches = await detector.detect(videoRef.current);
            const value = matches.find((match) => match.rawValue)?.rawValue?.trim();
            if (value) {
              stockIn.mutate({ data: { productId: selectedId, barcode: value } }, {
                onSuccess: (record) => {
                  completeStockIn(record);
                  setCameraNote(`Camera scanned ${value}.`);
                  setCameraOpen(false);
                  setTimeout(() => inputRef.current?.focus(), 20);
                },
              });
              stopCamera();
              return;
            }
          } catch {
            setCameraError('The camera is open, but this barcode could not be read. Try moving closer or use a hardware scanner.');
          }
          timer = window.setTimeout(() => void detect(), 250);
        };
        void detect();
      } catch {
        setCameraError('Camera permission was unavailable. Keyboard scanners still work normally.');
      }
    };

    void startCamera();
    return stopCamera;
  }, [active, cameraOpen, selectedId]);

  const camera = () => {
    setCameraError('');
    setCameraOpen(true);
  };
  return <><div className="page"><div className="page-heading"><div><div className="eyebrow">Stock intake</div><h1>Turn a scan into certainty.</h1><p className="page-subtitle">Choose one product. Scan every unit. Stop when the shelf is counted.</p></div><Link href="/data" className="button button-ghost" data-testid="link-view-scan-data"><Database size={15} />View scan data</Link></div>
    <div className="scan-layout"><section className="scan-hero"><div className="eyebrow" style={{ color: '#F6CDCE' }}>01 / select & scan</div><h2>Stock in, without second guesses.</h2><p>The active product is shared with Scan data, so your team always sees the same session context.</p>{productsQuery.isLoading ? <div className="skeleton" style={{ height: 48, marginTop: 27, opacity: .22 }} /> : products.length === 0 ? <div style={{ marginTop: 26, color: 'rgba(250,247,248,.7)', fontSize: 13 }}>Register a product first to begin scanning.</div> : <ProductSelect products={products} value={selectedId} onChange={choose} />}{selected && <><div className="scan-stock-readout"><span>On hand now</span><strong>{selected.stockCount}</strong><span>units</span></div><div className="scan-control">{!active ? <button className="button button-primary" onClick={start} disabled={!selectedId} data-testid="button-start-scan"><Play size={15} fill="currentColor" />Start stock-in</button> : <button className="button button-primary" onClick={end} data-testid="button-end-scan"><Square size={14} fill="currentColor" />End session</button>}<span style={{ alignSelf: 'center', font: '11px var(--app-font-mono)', color: 'rgba(250,247,248,.62)' }}>{active ? 'Listening for barcodes' : 'Session paused'}</span></div></>}</section>
      <section className="scan-input"><h3><Barcode size={18} style={{ verticalAlign: 'middle', marginRight: 7, color: '#85627E' }} />Barcode capture</h3><p>Hardware scanners type here and press Enter. Manual entry follows the same trusted API path.</p><form onSubmit={submitBarcode}><input ref={inputRef} className="barcode-input" value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder={active ? 'Ready for a barcode…' : 'Start a session first'} disabled={!active || stockIn.isPending} autoComplete="off" data-testid="input-stock-barcode" /></form>{active && <div className="camera-note"><button className="icon-button" onClick={camera} aria-label="Use camera scanner" data-testid="button-camera-scan"><Camera size={16} /></button><span>{cameraNote || 'Camera scan available where your browser permits it.'}</span></div>}{stockIn.isError && <p style={{ color: '#a33e47', fontSize: 12, marginTop: 14 }} data-testid="status-stock-error">{errorText(stockIn.error)}</p>}<div className="scan-log">{scanLog.length === 0 ? <div style={{ color: '#b397ae', fontSize: 12, textAlign: 'center', padding: '27px 0' }}>{active ? 'Scanned units will appear here.' : 'Your session log will appear here.'}</div> : scanLog.map((record) => <div className="scan-log-row" key={record.id} data-testid={`row-scan-success-${record.id}`}><Check className="scan-check" size={15} /><span className="scan-barcode">{record.barcode}</span><span className="scan-time">{record.scanTime}</span></div>)}</div></section>
   </div>
  </div>{cameraOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) setCameraOpen(false); }}><div className="modal" style={{ maxWidth: 560 }}><div className="modal-head"><div><h2>Scan with camera</h2><p className="modal-subtitle">Point your camera at the barcode for {selected?.name ?? 'this product'}.</p></div><button type="button" className="icon-button" onClick={() => setCameraOpen(false)} aria-label="Close camera scanner" data-testid="button-close-camera"><X /></button></div><div style={{ borderRadius: 14, overflow: 'hidden', background: '#332531', minHeight: 260, display: 'grid', placeItems: 'center' }}>{cameraError ? <div style={{ padding: 28, color: '#FAF7F8', textAlign: 'center', fontSize: 13, lineHeight: 1.6 }}>{cameraError}</div> : <video ref={videoRef} muted playsInline style={{ width: '100%', maxHeight: 360, objectFit: 'cover' }} />}</div><div className="form-actions"><button type="button" className="button button-ghost" onClick={() => setCameraOpen(false)} data-testid="button-cancel-camera">Close camera</button></div></div></div>}</>;
}

function DataPage() {
  const { session } = useSession();
  const productsQuery = useListProducts();
  const products = productsQuery.data ?? [];
  const [selectedId, setSelectedId] = useState<number | undefined>(session.productId);
  const [unsoldOnly, setUnsoldOnly] = useState(false);
  const [search, setSearch] = useState('');
  useEffect(() => { if (!selectedId && session.productId) setSelectedId(session.productId); }, [selectedId, session.productId]);
  const params = useMemo(() => ({ ...(selectedId ? { productId: selectedId } : {}), ...(search ? { search } : {}), ...(unsoldOnly ? { unsoldOnly: true } : {}) }), [selectedId, search, unsoldOnly]);
  const recordsQuery = useListScanRecords(params);
  const records = recordsQuery.data ?? [];
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">Per-unit truth</div><h1>Read the scan trail.</h1><p className="page-subtitle">A quiet ledger for the units moving through your shop.</p></div><div className="panel-kicker"><Wifi size={13} style={{ verticalAlign: 'middle', marginRight: 5, color: '#6f9e71' }} />Live from API</div></div>
    {session.productId && <div className="session-banner"><ScanLine size={15} />Active scan context: <strong>{session.productName}</strong><span style={{ marginLeft: 'auto' }}>{session.isScanning ? 'Session open' : 'Session paused'}</span></div>}
    <div className="panel"><div className="data-toolbar"><select className="select-field" value={selectedId ?? ''} onChange={(e) => setSelectedId(e.target.value ? Number(e.target.value) : undefined)} data-testid="select-data-product"><option value="">All products</option>{products.map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}</select><div className="search-bar" style={{ flex: 1, minWidth: 220 }}><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find a barcode…" aria-label="Search scan records" data-testid="input-search-records" /></div><button className={`filter-chip ${unsoldOnly ? 'active' : ''}`} onClick={() => setUnsoldOnly(!unsoldOnly)} data-testid="button-filter-unsold">{unsoldOnly ? 'Unsold only' : 'All units'}</button></div>
      {recordsQuery.isLoading ? <div className="skeleton" style={{ height: 260 }} /> : recordsQuery.isError ? <div className="error-state"><CircleAlert className="empty-icon" /><strong>Couldn’t read scan data</strong><span>{errorText(recordsQuery.error)}</span><br /><button className="button button-ghost" style={{ marginTop: 15 }} onClick={() => recordsQuery.refetch()} data-testid="button-retry-records"><RefreshCw size={14} />Try again</button></div> : records.length === 0 ? <div className="empty-state"><Barcode className="empty-icon" /><strong>No scan records match</strong><span>Start a stock-in session or broaden your filters.</span></div> : <div className="table-wrap"><table className="data-table"><thead><tr><th>Barcode</th><th>Product</th><th>Scanned</th><th>Expiry snapshot</th><th>Price</th><th>Status</th></tr></thead><tbody>{records.map((record) => <tr key={record.id} data-testid={`row-record-${record.id}`}><td className="mono">{record.barcode}</td><td>{record.productName}</td><td><span className="mono">{date(record.scanDate)}</span><br /><span style={{ color: '#b397ae', fontSize: 11 }}>{record.scanTime}</span></td><td>{date(record.expiryDateSnapshot)}</td><td className="mono">{money(record.sellingPriceSnapshot)}</td><td>{record.sellingDate ? <span className="sold-badge">Sold {shortDate(record.sellingDate)}</span> : <span className="unsold-badge">On hand</span>}</td></tr>)}</tbody></table></div>}
    </div>
  </div>;
}

function SellPage() {
  const [barcode, setBarcode] = useState('');
  const [recent, setRecent] = useState<ScanRecord[]>([]);
  const [notice, setNotice] = useState('');
  const sell = useSellBarcode();
  const inputRef = useRef<HTMLInputElement>(null);
  const recordsQuery = useListScanRecords({ unsoldOnly: false });
  const submit = (event?: FormEvent) => { event?.preventDefault(); const value = barcode.trim(); if (!value || sell.isPending) return; sell.mutate({ data: { barcode: value } }, { onSuccess: (record) => { setRecent((old) => [record, ...old].slice(0, 8)); setBarcode(''); setNotice(`${record.productName} marked sold.`); queryClient.invalidateQueries({ queryKey: getListScanRecordsQueryKey() }); queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); setTimeout(() => inputRef.current?.focus(), 20); } }); };
  useEffect(() => { if (!notice) return undefined; const timer = window.setTimeout(() => setNotice(''), 2600); return () => window.clearTimeout(timer); }, [notice]);
  const ledger = recordsQuery.data ?? [];
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">Passive checkout</div><h1>Keep the line moving.</h1><p className="page-subtitle">Leave the scanner listening. Each valid barcode closes one unit.</p></div><div className="panel-kicker"><span className="status-dot" style={{ background: '#6f9e71' }} />Scanner online</div></div>
    <div className="checkout-layout"><section className="checkout-card"><div className="eyebrow" style={{ color: '#F6CDCE' }}>QuickCart checkout</div><h2>Scan. Sell.<br />Done.</h2><p>Point your keyboard-emulation scanner at any stocked unit. The API checks ownership and marks it sold in one step.</p><div className="checkout-status"><span className="pulse" />PASSIVE LISTENER ACTIVE</div><form onSubmit={submit} style={{ marginTop: 22 }}><input ref={inputRef} className="barcode-input" style={{ background: 'rgba(250,247,248,.12)', borderColor: 'rgba(250,247,248,.25)', color: '#fff' }} value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder="Waiting for barcode…" autoFocus autoComplete="off" data-testid="input-sell-barcode" /></form>{sell.isError && <p style={{ color: '#F6CDCE', marginTop: 13 }} data-testid="status-sell-error">{errorText(sell.error)}</p>}</section>
      <section className="panel ledger-panel"><div className="ledger-head"><div><h2 className="panel-title">Master scan ledger</h2><div className="panel-kicker" style={{ marginTop: 4 }}>All units · newest first</div></div><Tag size={18} color="#B397AE" /></div>{recent.length > 0 && <div style={{ padding: '13px 21px', background: '#fff8f8', borderBottom: '1px solid #f0e7ee' }}>{recent.map((record) => <div className="scan-log-row" key={`recent-${record.id}`}><Check className="scan-check" size={15} /><span>{record.productName}</span><span className="scan-barcode">{record.barcode}</span><span className="scan-time">just now</span></div>)}</div>}{recordsQuery.isLoading ? <div className="skeleton" style={{ height: 280, borderRadius: 0 }} /> : recordsQuery.isError ? <div className="error-state" style={{ border: 0 }}><strong>Ledger unavailable</strong><span>{errorText(recordsQuery.error)}</span></div> : ledger.length === 0 ? <div className="empty-state" style={{ border: 0 }}><ShoppingCart className="empty-icon" /><strong>No units in the ledger yet</strong><span>Stock-in scans will appear here.</span></div> : <div className="table-wrap"><table className="data-table"><thead><tr><th>Unit barcode</th><th>Product</th><th>Scan date</th><th>Sell date</th><th>State</th></tr></thead><tbody>{ledger.slice(0, 20).map((record) => <tr key={record.id}><td className="mono">{record.barcode}</td><td>{record.productName}</td><td className="mono">{shortDate(record.scanDate)} · {record.scanTime}</td><td className="mono">{record.sellingDate ? `${shortDate(record.sellingDate)} · ${record.sellingTime}` : '—'}</td><td>{record.sellingDate ? <span className="sold-badge">Sold</span> : <span className="unsold-badge">On hand</span>}</td></tr>)}</tbody></table></div>}</section></div>
    {notice && <div className="toast-note" data-testid="status-sell-notice"><Check size={15} style={{ verticalAlign: 'middle', marginRight: 7 }} />{notice}</div>}
  </div>;
}

function TrendChart({ points }: { points: Analysis['salesTrend'] }) {
  const max = Math.max(...points.map((point) => point.revenue), 1);
  return <div className="trend" aria-label="Revenue trend">{points.length === 0 ? <span className="panel-kicker">No sales in this period.</span> : points.map((point) => <div className="bar-wrap" key={point.date} title={`${date(point.date)} · ${money(point.revenue)}`}><div className="bar" style={{ height: `${Math.max(5, (point.revenue / max) * 100)}%` }} /><span className="bar-label">{shortDate(point.date)}</span></div>)}</div>;
}

function AnalysisPage() {
  const [period, setPeriod] = useState<7 | 30 | 90>(30);
  const analysisQuery = useGetAnalysis({ period }, { query: { queryKey: getGetAnalysisQueryKey({ period }) } });
  const analysis = analysisQuery.data;
  if (analysisQuery.isLoading) return <div className="page"><div className="page-heading"><div><div className="eyebrow">Business pulse</div><h1>Reading your shop…</h1></div></div><div className="stat-grid">{[1, 2, 3, 4].map((i) => <div className="skeleton" style={{ height: 130 }} key={i} />)}</div><div className="skeleton" style={{ height: 360 }} /></div>;
  if (analysisQuery.isError || !analysis) return <div className="page"><div className="error-state"><CircleAlert className="empty-icon" /><strong>Analysis is taking a moment</strong><span>{errorText(analysisQuery.error)}</span><br /><button className="button button-ghost" style={{ marginTop: 15 }} onClick={() => analysisQuery.refetch()} data-testid="button-retry-analysis"><RefreshCw size={14} />Try again</button></div></div>;
  const totals = analysis.totals;
  const maxRevenue = Math.max(...analysis.revenueShare.map((item) => item.revenue), 1);
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">Business pulse</div><h1>Know what needs attention.</h1><p className="page-subtitle">Signals from your stock, sales, and expiry horizon.</p></div><div style={{ display: 'flex', gap: 5 }}><span className="panel-kicker" style={{ alignSelf: 'center', marginRight: 6 }}>Lookback</span>{([7, 30, 90] as const).map((value) => <button key={value} className={`filter-chip ${period === value ? 'active' : ''}`} onClick={() => setPeriod(value)} data-testid={`button-period-${value}`}>{value}d</button>)}</div></div>
    <div className="stat-grid"><div className="stat-card stat-accent"><div className="stat-label">Units in stock</div><div className="stat-value" data-testid="text-total-stock">{totals.unitsInStock}</div><div className="stat-note">Across {totals.products} products</div></div><div className="stat-card stat-pink"><div className="stat-label">Units sold</div><div className="stat-value">{totals.unitsSold}</div><div className="stat-note">In the last {period} days</div></div><div className="stat-card stat-lavender"><div className="stat-label">Revenue</div><div className="stat-value">{money(totals.revenue)}</div><div className="stat-note">Realized sell-through</div></div><div className="stat-card stat-soft"><div className="stat-label">Reorder signals</div><div className="stat-value">{totals.lowStock + totals.expiringSoon}</div><div className="stat-note">{totals.expiredUnsold} expired unsold</div></div></div>
    <div className="analysis-grid"><section className="panel"><div className="panel-heading"><div><h2 className="panel-title">Attention queue</h2><div className="panel-kicker" style={{ marginTop: 4 }}>{analysis.alerts.length} signals worth a look</div></div><ArrowUpRight size={18} color="#B397AE" /></div><div className="alerts-list">{analysis.alerts.length === 0 ? <div className="empty-state" style={{ padding: 35 }}>Nothing urgent. Your shelves are behaving.</div> : analysis.alerts.map((alert, index) => <div className={`alert-row ${alert.severity}`} key={`${alert.title}-${index}`}><AlertTriangle className="alert-icon" size={17} /><div><div className="alert-title">{alert.title}</div><div className="alert-detail">{alert.detail}</div></div></div>)}</div></section>
      <section className="panel"><div className="panel-heading"><div><h2 className="panel-title">Sales rhythm</h2><div className="panel-kicker" style={{ marginTop: 4 }}>Revenue · last {period} days</div></div><TrendingUp size={18} color="#85627E" /></div><TrendChart points={analysis.salesTrend} /></section>
      <section className="panel"><div className="panel-heading"><div><h2 className="panel-title">Product performance</h2><div className="panel-kicker" style={{ marginTop: 4 }}>Ranked by realized revenue</div></div><BarChart3 size={18} color="#B397AE" /></div><div className="ranking-list">{analysis.rankings.length === 0 ? <div className="empty-state" style={{ padding: 35 }}>Sales will shape your rankings.</div> : analysis.rankings.slice(0, 8).map((item, index) => <div className="ranking-row" key={item.productId}><span className="rank-num">0{index + 1}</span><span className="rank-name">{item.productName}</span><span className="rank-value">{money(item.revenue)}</span><span className={`mini-status ${item.status}`}>{item.status.replace('-', ' ')}</span></div>)}</div></section>
      <section className="panel"><div className="panel-heading"><div><h2 className="panel-title">Revenue share</h2><div className="panel-kicker" style={{ marginTop: 4 }}>Where the money is coming from</div></div><Tag size={18} color="#B397AE" /></div><div className="revenue-list">{analysis.revenueShare.length === 0 ? <div className="empty-state" style={{ padding: 35 }}>No revenue to split yet.</div> : analysis.revenueShare.slice(0, 7).map((item) => <div className="revenue-row" key={item.productName}><span className="revenue-name">{item.productName}</span><div className="revenue-track"><div className="revenue-fill" style={{ width: `${(item.revenue / maxRevenue) * 100}%` }} /></div><span className="revenue-amount">{money(item.revenue)}</span></div>)}</div></section>
    </div>
  </div>;
}

function Router() {
  return <ErrorBoundary><Switch><Route path="/" component={Home} /><Route path="/list"><Shell><ListPage /></Shell></Route><Route path="/scan"><Shell><ScanPage /></Shell></Route><Route path="/data"><Shell><DataPage /></Shell></Route><Route path="/sell"><Shell><SellPage /></Shell></Route><Route path="/analysis"><Shell><AnalysisPage /></Shell></Route><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function App() {
  const [session, setSession] = useState<Session>({ isScanning: false });
  return <QueryClientProvider client={queryClient}><TooltipProvider><SessionContext.Provider value={{ session, setSession }}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter></SessionContext.Provider><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;