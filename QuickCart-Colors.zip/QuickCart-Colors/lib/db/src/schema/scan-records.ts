import { createInsertSchema } from "drizzle-zod";
import {
  date,
  integer,
  numeric,
  pgTable,
  serial,
  text,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { productsTable } from "./products";

export const scanRecordsTable = pgTable("scan_records", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => productsTable.id, { onDelete: "cascade" }),
  // Product barcodes are commonly shared across every unit of the same product.
  // Each scan record represents one stocked unit, so duplicate barcodes are valid.
  barcode: text("barcode").notNull(),
  scanDate: date("scan_date", { mode: "string" }).notNull(),
  scanTime: text("scan_time").notNull(),
  mrpSnapshot: numeric("mrp_snapshot", {
    precision: 10,
    scale: 2,
    mode: "number",
  }).notNull(),
  expiryDateSnapshot: date("expiry_date_snapshot", {
    mode: "string",
  }).notNull(),
  sellingPriceSnapshot: numeric("selling_price_snapshot", {
    precision: 10,
    scale: 2,
    mode: "number",
  }).notNull(),
  sellingDate: date("selling_date", { mode: "string" }),
  sellingTime: text("selling_time"),
});

export const insertScanRecordSchema = createInsertSchema(scanRecordsTable).omit({
  id: true,
});
export type InsertScanRecord = z.infer<typeof insertScanRecordSchema>;
export type ScanRecord = typeof scanRecordsTable.$inferSelect;