# QuickCart — Full Application Build Prompt

Build a cross-platform inventory, barcode scanning, and sales-analysis application called **QuickCart**. The app is used by a retail shop/trolley system to register products, scan them into stock, scan them out at the point of sale, and automatically analyze sales performance, stock levels, and expiry risk.

Build this as a **responsive web app (works on desktop and mobile browser)**, with support for:
- USB-connected barcode scanner input (keyboard-emulation HID scanner)
- Bluetooth barcode scanner input (wireless HID/Bluetooth scanner)
- Mobile phone camera-based barcode scanning (using a barcode-scanning library, e.g. quagga.js / zxing / html5-qrcode)

Use a relational or document database (e.g., PostgreSQL, MySQL, or Firebase/MongoDB) to persist all data. All data entered must be saved permanently and reload correctly on app restart/refresh.

---

## GLOBAL STRUCTURE

**Top Navigation (present on every main screen):**
`List | Scan | Data | Sell | Analysis`

**Screen 1** is a splash/home screen shown on app launch, then routes to Screen 2 (List) by default.

---

## DATA MODEL

### Table: `products` (created/edited via Register form)
| Field | Type | Notes |
|---|---|---|
| id | UUID / auto-increment | primary key |
| name | string | required |
| weight | string/number | e.g. "500g" |
| mrp | decimal | Maximum Retail Price |
| selling_price | decimal | current selling price |
| manufacture_date | date | |
| expiry_date | date | |
| stock_count | integer | auto-calculated: total scanned-in units − total sold units |
| created_at / updated_at | timestamp | for "last updated" tracking |

### Table: `scan_records` (one row per physical unit scanned)
| Field | Type | Notes |
|---|---|---|
| id | UUID | primary key |
| product_id | FK → products.id | which product this unit belongs to |
| barcode | string | the scanned barcode number (unique per unit-instance) |
| scan_date | date | date of stock-in scan |
| scan_time | time | time of stock-in scan |
| mrp_snapshot | decimal | copied from product.mrp AT scan time — frozen, never updates later |
| expiry_date_snapshot | date | copied from product.expiry_date AT scan time — frozen |
| selling_price_snapshot | decimal | copied from product.selling_price AT scan time — frozen |
| selling_date | date | nullable — filled only when this barcode is scanned again at checkout |
| selling_time | time | nullable — filled only when this barcode is scanned again at checkout |

**Critical rule:** Editing a product's MRP/Selling Price/Expiry Date in the List tab must **never** retroactively change values already stored in existing `scan_records` rows. Only new scans going forward use the updated product values.

---

## SCREEN 1 — Splash/Home Screen

- Full-screen splash showing the app name/logo "QuickCart" for 1–2 seconds.
- Automatically navigates to Screen 2 (List tab) after load.

---

## SCREEN 2 — List Tab (Main Screen)

**Header:**
- Top nav tabs: List | Scan | Data | Sell | Analysis (List active/highlighted)
- Top-right: **Notification bell icon** with a badge count — shows the number of products whose `stock_count < 5`. Clicking it shows a dropdown/list of those low-stock products.

**Action bar (below header, above list):**
- **Register** button → opens a **modal popup** with a blank form:
  - Fields: Name, Weight, MRP, Selling Price (SP), Manufacture Date (M.D), Expiry Date (E.D)
  - Buttons: **Clear All** (resets the form fields) and **Save** (validates required fields, inserts a new row into `products`, closes modal, and the new item **automatically appears in the main list** below — no manual refresh needed)
- **Select All** button → toggles all item checkboxes on/off
- **Delete** button → disabled/greyed out by default; becomes active once ≥1 item is checked; on click, deletes the selected product(s) after a confirmation prompt (supports single or bulk delete)

**Item List (scrollable, unlimited items, with pagination or infinite scroll for performance):**

Each row displays, left to right:
1. **Item Name** — exactly as stored in `products.name`
2. **Edit** button/icon → opens the same modal as Register, but **pre-filled** with this item's current saved data; on Save, updates the existing row in `products` (does not create a duplicate) and reflects instantly in the list
3. **Info** button/icon → opens a small **read-only popup** showing this item's current saved details: Name, Weight, MRP, SP, M.D, E.D, and "Last Updated" timestamp
4. **Select checkbox** → for choosing this item (used with Select All / Delete)

A **search bar** should be included above the list to filter items by name.

---

## SCREEN 3 — Scan Tab

**Header:** Top nav (Scan active) + Search bar

**Layout — split into two sides:**

- **Left side:** A simple, view-only list of item names (pulled live from `products`), with the search bar filtering it. The user selects **exactly one item** from this list (radio-button style selection — selecting a new item deselects the previous one).
- **Right side:** Two buttons — **Scan Start** and **Scan End**

**Functionality:**
1. User selects a product from the left list.
2. Clicking **Scan Start** activates a listening state that accepts barcode input from any of these three sources:
   - USB barcode scanner (reads as rapid keyboard input terminated by Enter — capture via a hidden/focused input field)
   - Bluetooth barcode scanner (same HID keyboard-emulation capture method)
   - Mobile camera (invoke device camera via a JS barcode-scanning library and decode in real time)
3. On each successful barcode read:
   - Create a new row in `scan_records` with: `product_id` = selected product, `barcode` = scanned value, `scan_date`/`scan_time` = now, `mrp_snapshot`/`expiry_date_snapshot`/`selling_price_snapshot` = copied from the selected product's current values.
   - Increment that product's `stock_count`.
   - Show a brief on-screen confirmation (e.g., toast: "Scanned: [barcode] → linked to [Product Name]").
4. Clicking **Scan End** deactivates the listener/closes the camera.

**Sync requirement:** The selected product and active scan session state (Start/End) must be **shared/synced in real time** with Screen 4 (Data tab) — selecting an item or toggling scan here should reflect immediately if the user switches to Screen 4, and vice versa (use shared app state / context / websocket or polling).

---

## SCREEN 4 — Data Tab

**Header:** Top nav (Data active) + Search bar + same single-select item list as Screen 3 (synced state)

**Right side:** Scan Start / Scan End buttons — same shared session/state as Screen 3 (clicking either screen's buttons controls the one active session).

**Table (shows `scan_records` filtered to the currently selected product only):**

| Barcode | Date | Time | Expiry Date | Selling Price |
|---|---|---|---|---|

- Each row = one `scan_records` entry for the selected product.
- Populated automatically as barcodes are scanned (from either Screen 3 or Screen 4, since they're the same session).
- Switching the selected product shows that product's own separate scan table (i.e., conceptually a separate "sheet" per product, implemented as a filtered query on `product_id`).

---

## SCREEN 5 — Sell Tab

**Header:** Top nav (Sell active)

**No Scan Start/End buttons on this screen.** Instead, this screen passively listens for input from a **separate, dedicated wireless barcode scanner** used at the point-of-sale/checkout counter (also captured as HID keyboard-emulation input, always listening while this tab is open).

**Table (shows ALL scan_records across all products — this is the master per-unit ledger):**

| Barcode | Scan Date | Scan Time | MRP | Expiry Date | Selling Price | Selling Date | Selling Time |
|---|---|---|---|---|---|---|---|

Columns map directly to `scan_records` fields: `barcode`, `scan_date`, `scan_time`, `mrp_snapshot`, `expiry_date_snapshot`, `selling_price_snapshot`, `selling_date`, `selling_time`.

**Checkout scan logic:**
1. When the checkout scanner reads a barcode, search `scan_records` for a row where `barcode` matches AND `selling_date` is currently NULL (i.e., this exact unit hasn't been sold yet).
2. If found: update that row's `selling_date` and `selling_time` to the current date/time. **Do not create a new row.**
3. Decrement the matching product's `stock_count` by 1.
4. If no matching unsold barcode is found, show an error/warning (e.g., "Barcode not found in stock" or "Already sold").
5. Include a search bar to filter this table by barcode, product name, or date range.

---

## SCREEN 6 — Analysis Tab

**Header:** Top nav (Analysis active)

Build a dashboard that runs analysis logic (server-side computation or client-side aggregation) over `products` + `scan_records` data:

### 1. Stock Alerts
- List all products where `stock_count < 5`, sorted by lowest stock first. Display as a highlighted alert banner/list at the top.

### 2. Best-Seller / Slow-Mover Ranking
- Group `scan_records` by `product_id` where `selling_date IS NOT NULL`, count units sold (overall and per selectable time period: 7/30/90 days).
- Rank descending → "Top Sellers"; rank ascending (including zero-sales products) → "Slow Movers", flagged for action.

### 3. Expiry Risk Analysis
- For rows where `selling_date IS NULL` (unsold units): calculate `days_until_expiry = expiry_date_snapshot - today`.
- Alert products/units expiring within 7 days and still unsold.
- Separately count/list units where `expiry_date_snapshot < today` and `selling_date IS NULL` → "Expired & Unsold (Wastage)".

### 4. Sell-Through Speed
- For rows where `selling_date IS NOT NULL`: calculate `days_to_sell = selling_date - scan_date`.
- Compute average `days_to_sell` per product → flag products with unusually long average sell time as slow-moving/overstocked.

### 5. Revenue & Discount Insights
- Revenue per product = SUM(`selling_price_snapshot`) for sold units.
- Discount given per unit = `mrp_snapshot - selling_price_snapshot`; aggregate per product to show which items are frequently discounted vs sold at full MRP.
- Show "Top Revenue Generators" separately from "Top Unit Sellers" (these can differ).

### 6. Demand Trend & Predictive Restock Alert
- Compute recent sales velocity (units sold per day, trailing 7/14 days) per product.
- Compare to current `stock_count` to estimate days-until-stockout: `estimated_days_left = stock_count / avg_daily_sales_rate`.
- Alert when `estimated_days_left` is low (e.g., < 3 days) — "Reorder Soon" suggestion.

### Suggested Visual Layout
- **Top:** Alert banners (Low Stock / Expiring Soon / Expired-Unsold / Reorder Soon)
- **Middle:** Charts — bar chart (top sellers vs slow movers), line chart (sales trend over time), pie chart (revenue share by product)
- **Bottom:** A sortable/filterable ranked table:
  `Product | Units Sold | Revenue | Avg. Days to Sell | Stock Left | Status (🔴 Low Stock / 🟡 Near Expiry / 🟢 Healthy)`

---

## NON-FUNCTIONAL REQUIREMENTS

- All popups/modals (Register, Edit, Info) must overlay the current screen without full page navigation, and close on Save/Cancel/outside-click.
- Barcode scanner input handling must work identically whether the source is USB, Bluetooth, or mobile camera — normalize all three into the same "on barcode scanned" event handler.
- All list/table views should support real-time or near-real-time updates (no manual refresh needed) after Register, Edit, Delete, or Scan actions.
- Use consistent snapshot logic: `mrp_snapshot`, `expiry_date_snapshot`, `selling_price_snapshot` are written once at scan-in time and are immutable afterward, even if the source product is later edited.
- Ensure barcode uniqueness is handled at the **unit level**, not the product level (the same product can have many different physical units/barcodes in stock simultaneously).
- Mobile-responsive layout required throughout (this app will be used on both a desktop/checkout terminal and a mobile phone at the shop floor/trolley).
